package com.nju.software;

public class Producer implements Runnable {

	private Resources resources;

	public Producer() {
	};

	public Producer(Resources resources) {
		this.resources = resources;
	};

	public Resources getResources() {
		return resources;
	}

	public void setResources(Resources resources) {
		this.resources = resources;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
	
			resources.addResource();

		}
	}

}
