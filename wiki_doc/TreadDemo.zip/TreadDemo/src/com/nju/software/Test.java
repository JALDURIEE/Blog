package com.nju.software;

public class Test {

	/**  
	 * ����
	 * @param args  
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Resources resources = new Resources();
		Thread p = new Thread(new Producer(resources));
		Thread c = new Thread(new Consumer(resources));
		p.start();
		c.start();
		
		int i =0;
		
		synchronized(Test.class){
			 i++;
		}

	}

}
