package com.nju.software;

public class Consumer implements Runnable {

	private Resources resources;

	public Consumer() {
	};

	public Consumer(Resources resources) {
		this.resources = resources;
	};

	public Resources getResources() {
		return resources;
	}

	public void setResources(Resources resources) {
		this.resources = resources;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			resources.removeResource();
		}
	}


}
