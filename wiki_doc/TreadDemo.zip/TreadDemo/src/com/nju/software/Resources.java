package com.nju.software;

import java.util.ArrayDeque;
import java.util.Queue;

public class Resources {

	private Queue<Resource> queue = new ArrayDeque<Resource>();
	private int num = 1;
	private boolean flag = true;

	synchronized public void addResource( ) {
		if (num <=0) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			Resource r = null;
			if (flag) {
				r = new Resource("tiancong", "tiancong");
				flag= false;
			} else {
				r = new Resource("JALDURIEE", "xinliang");
				flag = true;
			}
			queue.add(r);
			num--;
			System.out.println("add-->"+r);
			this.notifyAll();
		}
	}
	
	synchronized public void removeResource(){
		if(num>=1){
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			Resource r = queue.poll();
			System.out.println("delete-->"+r);
			num++;
//			this.notify();
			this.notifyAll();
		}
	}

}
